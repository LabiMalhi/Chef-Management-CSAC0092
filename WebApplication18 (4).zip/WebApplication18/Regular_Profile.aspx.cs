﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication18
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        public string cnstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(cnstring);


            con.Open();
            if (con.State == System.Data.ConnectionState.Open)
            {
                string b = "insert into accessrequest (f_name,l_name,department,phone_number,request_status)values('" + TextBox3.Text.ToString() + "','" + TextBox4.Text + "','" + TextBox8.Text.ToString() + "','" + TextBox7.Text + "','" + "Pending" + "')";

                SqlCommand cmd = new SqlCommand(b, con);


                cmd.ExecuteNonQuery();

                Response.Write("Request Send");
            }
        }
    }
}