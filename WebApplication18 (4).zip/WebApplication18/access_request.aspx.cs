﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace WebApplication18
{
    public partial class access_request : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSource = SqlDataSource1;
                GridView1.DataBind();
            }
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button15_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in GridView1.Rows)
            {
                CheckBox status = (row.Cells[5].FindControl("CheckBox1") as CheckBox);
                double applicationid = Convert.ToDouble(row.Cells[1].Text);
                if (status.Checked)
                {
                    updaterow(applicationid, "Approved");
                }
               



            }
            Label1.Text = "User aplication approved.";
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();

        }
        private void updaterow(double applicationid, String approval)
        {
            String mycon = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";
            String updatedata = "Update accessrequest set request_status = '" + approval + "' where phone_number =" + applicationid;
            SqlConnection con = new SqlConnection(mycon);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updatedata;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        protected void Button16_Click(object sender, EventArgs e)
        {
            foreach (GridViewRow row in GridView1.Rows)
            {
                CheckBox status = (row.Cells[5].FindControl("CheckBox1") as CheckBox);
                double applicationid = Convert.ToDouble(row.Cells[1].Text);
                if (status.Checked)
                {
                    updaterow(applicationid, "Declined");
                }
                



            }
            Label1.Text = "User aplication declined.";
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
        }
    }
}