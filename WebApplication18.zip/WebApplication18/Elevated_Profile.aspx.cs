﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication18
{
    public partial class Elevated_Profile : System.Web.UI.Page
    {
        public string cnstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["user"] != null)
            {
                con = new SqlConnection(cnstring);
                con.Open();
                showdata();
            }

        }
        public void showdata()  // identication of user by adding name of the user
        {
            cmd.CommandText = "select * from useradd where email = '" + Session["user"] + "'";
            cmd.Connection = con;
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            Label1.Text = ds.Tables[0].Rows[0]["f_name"].ToString();


            TextBox1.Text = ds.Tables[0].Rows[0]["email"].ToString();// For auto fill all the data of the user
            TextBox2.Text = ds.Tables[0].Rows[0]["pass"].ToString();
            TextBox3.Text = ds.Tables[0].Rows[0]["f_name"].ToString();
            TextBox4.Text = ds.Tables[0].Rows[0]["l_name"].ToString();
            TextBox12.Text = ds.Tables[0].Rows[0]["dob"].ToString();
            DropDownList2.SelectedItem.Text = ds.Tables[0].Rows[0]["access_type"].ToString();
            TextBox7.Text = ds.Tables[0].Rows[0]["phone_number"].ToString();
            DropDownList1.SelectedItem.Text = ds.Tables[0].Rows[0]["department"].ToString();
            TextBox11.Text = ds.Tables[0].Rows[0]["address"].ToString();
        }

      

        protected void Button8_Click(object sender, EventArgs e)
        {
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
            TextBox3.Text = string.Empty;
            TextBox4.Text = string.Empty;
            TextBox12.Text = string.Empty;
            TextBox7.Text = string.Empty;
            TextBox11.Text = string.Empty;
            DropDownList2.SelectedItem.Text = string.Empty;
            DropDownList1.SelectedItem.Text = string.Empty;

        }

        protected void Button4_Click(object sender, EventArgs e)
        {

            if (checkemail() == false)
            {
                string script = "alert('Your Email does not exists');"; ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
                TextBox1.BackColor = System.Drawing.Color.PaleGreen;


            }
            else
            {

                if (phone() == false)
                {
                    string script = "alert('This Phone number does not exists');"; ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
                    TextBox7.BackColor = System.Drawing.Color.PaleGreen;


                }
                else
                {
                    SqlConnection con = new SqlConnection(cnstring);


                    con.Open();
                    if (con.State == System.Data.ConnectionState.Open)
                    {
                        string b = "update useradd SET email='" + TextBox1.Text + "',pass = '" + TextBox2.Text + "',f_name = '" + TextBox3.Text + "',l_name = '" + TextBox4.Text + "',dob = '" + TextBox12.Text + "',access_type = '" + DropDownList2.SelectedItem.Text + "',department = '" + DropDownList1.SelectedItem.Text + "',address = '" + TextBox11.Text + "' where phone_number = '" + TextBox7.Text + "'";

                        SqlCommand cmd = new SqlCommand(b, con);


                        cmd.ExecuteNonQuery();

                        Response.Write("Update Suceesfully");
                    }
                }
            }

            // to empty all the texfiled after submission

            TextBox1.Text = String.Empty;
            TextBox2.Text = String.Empty;
            TextBox3.Text = String.Empty;
            TextBox4.Text = String.Empty;
            TextBox12.Text = String.Empty;
            DropDownList2.SelectedItem.Text = String.Empty;
            DropDownList1.SelectedItem.Text = String.Empty;
            TextBox11.Text = String.Empty;
            TextBox7.Text = String.Empty;



        }
        private Boolean checkemail()
        {
            Boolean emailavailable = false;

            String b = "Select * from useradd where email='" + TextBox1.Text + "'";
            SqlConnection con = new SqlConnection(cnstring);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = b;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                emailavailable = true;

            }
            con.Close();

            return emailavailable;

        }
        private Boolean phone()
        {
            Boolean phoneavailable = false;

            String b = "Select * from useradd where phone_number='" + TextBox7.Text + "'";
            SqlConnection con = new SqlConnection(cnstring);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = b;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                phoneavailable = true;

            }
            con.Close();

            return phoneavailable;

        }
    }
}