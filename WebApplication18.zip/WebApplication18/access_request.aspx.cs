﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication18
{
    public partial class access_request : System.Web.UI.Page
    {
        public string cnstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSource = SqlDataSource1;
                GridView1.DataBind();
            }
            {
                if (Session["user"] != null)
                {
                    con = new SqlConnection(cnstring);
                    con.Open();
                    showdata();
                }
            }
        }
        public void showdata()  // identication of user by adding name of the user
        {
            cmd.CommandText = "select * from useradd where email = '" + Session["user"] + "'";
            cmd.Connection = con;
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            Label2.Text = ds.Tables[0].Rows[0]["f_name"].ToString();
           
        }



        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        protected void Button15_Click(object sender, EventArgs e)//approve request button
        {
            foreach (GridViewRow row in GridView1.Rows)
            {
                CheckBox status = (row.Cells[3].FindControl("CheckBox1") as CheckBox);
                int r_id = Convert.ToInt32(row.Cells[1].Text);
                if (status.Checked)
                {
                    updaterow(r_id, "Approved");
                }

            }
            Label1.Text = "Applications Has Been Approved Successfully";
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();

        }
        private void updaterow(int r_id, String request_status)//update data 
        {

            String updatedata = "Update accessrequest set request_status='" + request_status + "' where r_id=" + r_id;
            SqlConnection con = new SqlConnection(cnstring);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = updatedata;
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
        }

        protected void Button16_Click(object sender, EventArgs e)//decline request button
        {

            foreach (GridViewRow row in GridView1.Rows)
            {
                CheckBox status = (row.Cells[3].FindControl("CheckBox1") as CheckBox);
                int r_id = Convert.ToInt32(row.Cells[1].Text);
                if (status.Checked)

                {
                    updaterow(r_id, "Declined");

                }
            }
            Label1.Text = "Applications Has Been Declined";
            SqlDataSource1.DataBind();
            GridView1.DataSource = SqlDataSource1;
            GridView1.DataBind();
        }
    }
}
