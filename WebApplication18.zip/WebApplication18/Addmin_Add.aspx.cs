﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication18
{
    public partial class Addmin_Add : System.Web.UI.Page
    {
        public string cnstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                con = new SqlConnection(cnstring);
                con.Open();
                showdata();
            }
        }
        public void showdata()  // identication of user by adding name of the user
        {
            cmd.CommandText = "select * from useradd where email = '" + Session["user"] + "'";
            cmd.Connection = con;
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            Label1.Text = ds.Tables[0].Rows[0]["f_name"].ToString();

        }




        protected void Button4_Click(object sender, EventArgs e)
        {

            if (checkemail() == true)
            {
                string script = "alert('Your Email is already exists');"; ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
                TextBox1.BackColor = System.Drawing.Color.PaleGreen;


            }
            else
            {

                if (phone() == true)
                {
                    string script = "alert('This Phone number already exists');"; ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
                    TextBox7.BackColor = System.Drawing.Color.PaleGreen;


                }
                else
                {
                    SqlConnection con = new SqlConnection(cnstring);


                    con.Open();
                    if (con.State == System.Data.ConnectionState.Open)
                    {
                        string b = "insert into useradd (email,pass,f_name,l_name,dob,access_type,phone_number,department,address)values('" + TextBox1.Text.ToString() + "','" + TextBox2.Text + "','" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox12.Text + "','" + DropDownList2.SelectedItem.Text + "','" + TextBox7.Text.ToString() + "','" + DropDownList1.SelectedItem.Text + "','" + TextBox11.Text + "')";

                        SqlCommand cmd = new SqlCommand(b, con);


                        cmd.ExecuteNonQuery();

                        Response.Write("New user added");
                    }
                }
            }
            TextBox1.Text = String.Empty;
            TextBox2.Text = String.Empty;
            TextBox3.Text = String.Empty;
            TextBox4.Text = String.Empty;
            TextBox12.Text = String.Empty;
            DropDownList2.SelectedItem.Text = String.Empty;
            TextBox7.Text = String.Empty;
            DropDownList1.SelectedItem.Text = String.Empty;
            TextBox11.Text = String.Empty;

        }
        private Boolean checkemail()
        {
            Boolean emailavailable = false;

            String b = "Select * from useradd where email='" + TextBox1.Text + "'";
            SqlConnection con = new SqlConnection(cnstring);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = b;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                emailavailable = true;

            }
            con.Close();

            return emailavailable;

        }
        private Boolean phone()
        {
            Boolean phoneavailable = false;

            String b = "Select * from useradd where phone_number='" + TextBox7.Text + "'";
            SqlConnection con = new SqlConnection(cnstring);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = b;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                phoneavailable = true;

            }
            con.Close();

            return phoneavailable;

        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            TextBox1.Text = string.Empty;
            TextBox2.Text = string.Empty;
            TextBox3.Text = string.Empty;
            TextBox4.Text = string.Empty;
            TextBox12.Text = string.Empty;
            TextBox7.Text = string.Empty;
            TextBox11.Text = string.Empty;
            DropDownList2.SelectedItem.Text = string.Empty;
            DropDownList1.SelectedItem.Text = string.Empty;
        }
    }
}

