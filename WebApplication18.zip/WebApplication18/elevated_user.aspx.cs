﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


namespace WebApplication18
{
    public partial class elevated_user : System.Web.UI.Page
    {
        public string cnstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";
        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["user"] != null)
            {
                con = new SqlConnection(cnstring);
                con.Open();
                showdata();

            }
        }

        public void showdata()  // identication of user by adding name of the user
        {
            cmd.CommandText = "select * from useradd where email = '" + Session["user"] + "'";
            cmd.Connection = con;
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            Label1.Text = ds.Tables[0].Rows[0]["f_name"].ToString();

        }

        protected void Button12_Click(object sender, EventArgs e)//edit button
        {




            foreach (GridViewRow row in GridView1.Rows)
            {
                CheckBox status = (row.Cells[3].FindControl("CheckBox1") as CheckBox);
                int r_id = Convert.ToInt32(row.Cells[1].Text);
                int phone_number = Convert.ToInt32(row.Cells[1].Text);
                if (status.Checked)
                {
                    String update = "Update accessrequest set r_id='" + r_id + "' where phone_number=" + phone_number;



                    SqlConnection con = new SqlConnection(cnstring);
                    con.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = update;
                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    Label8.Text = "Row Data Has Been Updated Successfully";
                    GridView1.EditIndex = -1;
                    SqlDataSource1.DataBind();

                    GridView1.DataSource = SqlDataSource1;
                    GridView1.DataBind();

                }
            }

        }

       
      

        protected void Button14_Click1(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(cnstring))
            {
                {
                    using (SqlCommand cmd = new SqlCommand("select * from useradd where f_name = '" + TextBox4.Text + "'"))
                    {
                        SqlDataAdapter dt = new SqlDataAdapter();
                        try
                        {
                            cmd.Connection = con;
                            con.Open();
                            dt.SelectCommand = cmd;

                            DataTable dTable = new DataTable();
                            dt.Fill(dTable);

                            GridView1.DataSource = dTable;
                            GridView1.DataBind();
                        }
                        catch (Exception)
                        {
                            //     
                        }
                    }
                }
            }
        }
    }
}