﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication18
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        string cnstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Database1.mdf;Integrated Security=True";

        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();
        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        protected void Page_Load(object sender, EventArgs e)  // For auto fill all the data of the user after sigin
        {
            if (Session["user"] != null)  
            {

                con = new SqlConnection(cnstring);
                con.Open();
                showdata();
            }
        }
      
        public void showdata()  
        {
            cmd.CommandText = "select * from useradd where email = '" + Session["user"] + "'";
            cmd.Connection = con;
            sda.SelectCommand = cmd;
            sda.Fill(ds);
            Label1.Text = ds.Tables[0].Rows[0]["f_name"].ToString();// for identification by adding name of the user 
            TextBox1.Text = ds.Tables[0].Rows[0]["email"].ToString();// For auto fill all the data of the user
            TextBox2.Text = ds.Tables[0].Rows[0]["pass"].ToString();
            TextBox3.Text = ds.Tables[0].Rows[0]["f_name"].ToString();
            TextBox4.Text = ds.Tables[0].Rows[0]["l_name"].ToString();
            TextBox12.Text = ds.Tables[0].Rows[0]["dob"].ToString();
            TextBox7.Text = ds.Tables[0].Rows[0]["phone_number"].ToString();
            TextBox13.Text = ds.Tables[0].Rows[0]["department"].ToString();
            TextBox11.Text = ds.Tables[0].Rows[0]["address"].ToString();
        }
        protected void Button4_Click(object sender, EventArgs e)

        {

            SqlConnection con = new SqlConnection(cnstring);
            con.Open();
            DataSet ds = new DataSet();

            SqlCommand cmd = new SqlCommand("select * from accessrequest where phone_number='" + TextBox7.Text + "'", con);
            SqlDataAdapter da = new SqlDataAdapter();

            cmd.CommandType = CommandType.Text;
            da.SelectCommand = cmd;
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                String phone = ds.Tables[0].Rows[0]["phone_number"].ToString();
                if (phone == TextBox7.Text)
                {

                    String request = ds.Tables[0].Rows[0]["request_status"].ToString();
                    con.Close();
                    if (request == "Pending")
                    {
                        Label2.Text = "Access Request Is Already Sent";
                    }
                    else (request == "Declined")
                    {

                        string b = "insert into accessrequest (f_name,l_name,phone_number,department,request_status)values('" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox7.Text.ToString() + "','" + TextBox13.Text + "','" + "Pending" + "')";

                        SqlCommand cmd = new SqlCommand(b, con);


                        cmd.ExecuteNonQuery();

                        Response.Write("Request has been sent");
                    }
                }
            }
            else
            {

                con.Open();
                if (con.State == System.Data.ConnectionState.Open)
                {

                    string b = "insert into accessrequest (f_name,l_name,phone_number,department,request_status)values('" + TextBox3.Text + "','" + TextBox4.Text + "','" + TextBox7.Text.ToString() + "','" + TextBox13.Text + "','" + "Pending" + "')";

                    SqlCommand cmd = new SqlCommand(b, con);


                    cmd.ExecuteNonQuery();

                    Response.Write("Request has been sent");
                }

            }

        }
        
            
        protected void Button3_Click(object sender, EventArgs e)
        {
            if (checkemail() == false) // check already existed email in the database
            {
                string script = "alert('Your Email does not exists');"; ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
                TextBox1.BackColor = System.Drawing.Color.PaleGreen;


            }
            else
            {

                if (phone() == false) // check already existed phone number in the database
                {
                    string script = "alert('This Phone number does not exists');"; ClientScript.RegisterClientScriptBlock(this.GetType(), "Alert", script, true);
                    TextBox7.BackColor = System.Drawing.Color.PaleGreen;


                }
                else // for editing data of the user
                {

                    SqlConnection con = new SqlConnection(cnstring);


                    con.Open();
                    if (con.State == System.Data.ConnectionState.Open)
                    {
                        string b = "update useradd SET email='" + TextBox1.Text + "',pass = '" + TextBox2.Text + "',f_name = '" + TextBox3.Text + "',l_name = '" + TextBox4.Text + "',dob = '" + TextBox12.Text + "',address = '" + TextBox11.Text + "' where phone_number = '" + TextBox7.Text + "'";

                        SqlCommand cmd = new SqlCommand(b, con);


                        cmd.ExecuteNonQuery();

                        Response.Write("Updated Suceesfully");
                    }
                }
            }
             // to empty all the texfiled after submission

            TextBox1.Text = String.Empty;
            TextBox2.Text = String.Empty;

            TextBox3.Text = String.Empty;
            TextBox4.Text = String.Empty;

            TextBox12.Text = String.Empty;
            TextBox11.Text = String.Empty;
            TextBox7.Text = String.Empty;
            TextBox13.Text = String.Empty;



        }
        private Boolean checkemail() // for already existed email in the databse
        {
            Boolean emailavailable = false;

            String b = "Select * from useradd where email='" + TextBox1.Text + "'";
            SqlConnection con = new SqlConnection(cnstring);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = b;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                emailavailable = true;

            }
            con.Close();

            return emailavailable;

        }
        private Boolean phone() // for already existed phone number in the database
        {
            Boolean phoneavailable = false;

            String b = "Select * from useradd where phone_number='" + TextBox7.Text + "'";
            SqlConnection con = new SqlConnection(cnstring);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = b;
            cmd.Connection = con;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                phoneavailable = true;

            }
            con.Close();

            return phoneavailable;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {

        }
    }
}
       



